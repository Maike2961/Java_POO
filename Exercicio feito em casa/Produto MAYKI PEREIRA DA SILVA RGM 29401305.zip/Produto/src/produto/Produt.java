/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produto;

/**
 *
 * @author mayki
 */
public class Produt {
    String marca;
    String fabricante;
    String cod_barras;
    float preco;
    
public Produt(){}


public Produt(String m, String f, String c, float p){
marca = m;
fabricante = f;
cod_barras = c;
preco = p;

}
}
