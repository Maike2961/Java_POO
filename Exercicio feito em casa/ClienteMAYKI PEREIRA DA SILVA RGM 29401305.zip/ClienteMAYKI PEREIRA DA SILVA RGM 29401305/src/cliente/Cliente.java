/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

/**
 *
 * @author mayki
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Client v1 = new Client();
        v1.nome ="maike";
        v1.email = "mayki.silva@hotmial.com";
        v1.idade = 22;
        System.out.println("o nome do cliente é: "+v1.nome);
        System.out.println("o e-mail é: "+v1.email);
        System.out.println("a idade é: "+v1.idade);
    }
    
}
