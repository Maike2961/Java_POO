/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

/**
 *
 * @author mayki pereira da silva
 *  RGM 29401305
 */
public class Client {
    String nome;
    String email;
    int idade;
    
}
